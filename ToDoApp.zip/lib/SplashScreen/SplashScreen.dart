import 'package:todoapp_/Pages/HomePage/HomePage.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:page_transition/page_transition.dart';

class Colorss {
  static Color blue = Color.fromARGB(255, 108, 180, 209);
  static Color green = Color.fromARGB(255, 55, 236, 185);
  static Color gray = Color.fromARGB(255, 104, 107, 109);
  static Color darkGray = Color.fromARGB(255, 78, 78, 78);


}

class SplashScreen extends StatefulWidget {
  SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 30), () {
      Navigator.push(
        context,
        PageTransition(
          type: PageTransitionType.fade, // Choose your desired transition type
          duration:
              Duration(milliseconds: 500), // Set the duration of the transition
          child: MyHomePage(
            title: 'hi',
          ), // Replace HomeScreen with your destination screen widget
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color.fromARGB(255, 108, 180, 209),
                Color.fromARGB(255, 55, 236, 185),
              ]),
        ),
        width: double.infinity,
        height: double.infinity,
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(top: height * 0.45),
              child: Stack(
                children: [
                  Text(
                    'مرحبا',
                    style: GoogleFonts.elMessiri(
                        textStyle: TextStyle(
                      fontSize: 60,
                      foreground: Paint()
                        ..style = PaintingStyle.stroke
                        ..strokeWidth = 6
                        ..color = Color.fromRGBO(0, 0, 0, 0.06)!,
                    )),
                  ),
                  Text(
                    'مرحبا',
                    style: GoogleFonts.elMessiri(
                        textStyle: const TextStyle(
                      fontSize: 60,
                      color: Colors.white,
                      // // fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          blurRadius: 4, // shadow blur
                          color:
                              Color.fromRGBO(0, 0, 0, 0.25), // shadow color
                          offset:
                              Offset(0, 4), // how much shadow will be shown
                        ),
                      ],
                    )),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: height * 0.3,
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                width: width * 0.4,
                // color: Colors.amber,
                child: Image.asset(
                  'assets/images/logo.png',
                  width: width * 0.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
