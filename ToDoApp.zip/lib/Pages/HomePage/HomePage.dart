import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import '../../Data/model/model.dart';
import '../../SplashScreen/SplashScreen.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  //------------------------
  //Variables
  //------------------------
  List<TodoData> todoList = [];
  bool done = false, complated = true;

  //------------------------
  //Variables
  //------------------------

  Future<List<TodoData>> fetchData() async {
    final response =
        await http.get(Uri.parse('https://jsonplaceholder.typicode.com/todos'));

    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      List<TodoData> todoList =
          body.map((dynamic item) => TodoData.fromJson(item)).toList();
      return todoList;
    } else {
      throw "Failed in loading ";
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData().then((value) {
      setState(() {
        todoList.addAll(value);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    print(width * 0.07);

    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          toolbarHeight: height * 0.1,
          titleSpacing: 40,
          automaticallyImplyLeading: false,
          title: Text(
            done ? 'المنجزه' : "الغير منجز",
            style: GoogleFonts.elMessiri(
                textStyle: const TextStyle(
              fontSize: 20,
              color: Colors.grey,
            )),
          ),
          centerTitle: true,
          shape: Border(
              bottom: BorderSide(
                  color: Colorss.darkGray.withOpacity(0.2), width: 3)),
        ),

//____________________________Body_________________________________________
        body: Container(
          child: SingleChildScrollView(
            child: Center(
              child: Stack(
                fit: StackFit.passthrough,
                children: [
                  Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        //------space-------
                        SizedBox(
                          height: height * 0.03,
                        ),
                        //------End of space-------

                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        //?----------first section including the two buttons
                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        Container(
                          height: height * 0.09,
                          width: width * 0.8,
                          //!remove letter
                          // color: Colors.amber,
                          //!remove letter
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              /*---------------------is not done yet bottom--------------------*/
                              GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      done = false;
                                    });
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    height: height * 0.05,
                                    width: width * 0.3,
                                    decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                            color:
                                                Colors.black.withOpacity(0.25),
                                            blurRadius: 15,
                                            offset: Offset(0, 4),
                                            spreadRadius: -5)
                                      ],
                                      gradient: LinearGradient(
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                          colors: done
                                              ? [
                                                  Color.fromARGB(
                                                      255, 108, 180, 209),
                                                  Color.fromRGBO(
                                                      64, 226, 190, 1)
                                                ]
                                              : [
                                                  Color.fromARGB(
                                                      255, 108, 180, 209),
                                                  Color.fromARGB(
                                                      255, 108, 180, 209),
                                                ]),
                                    ),
                                    child: textstyle(
                                        'غير منجز', 17.0, Colors.white),
                                  )),
                              /*---------------------is  done  bottom---------------------*/
                              GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      done = true;
                                    });
                                  },
                                  child: Container(
                                    alignment: Alignment.center,
                                    height: height * 0.05,
                                    width: width * 0.3,
                                    decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                            color:
                                                Colors.black.withOpacity(0.25),
                                            blurRadius: 15,
                                            offset: Offset(0, 4),
                                            spreadRadius: -5)
                                      ],
                                      gradient: LinearGradient(
                                          begin: Alignment.topLeft,
                                          end: Alignment.bottomRight,
                                          colors: done
                                              ? [
                                                  Color.fromARGB(
                                                      255, 108, 180, 209),
                                                  Color.fromARGB(
                                                      255, 108, 180, 209)
                                                ]
                                              : [
                                                  Color.fromARGB(
                                                      255, 108, 180, 209),
                                                  Color.fromRGBO(
                                                      64, 226, 190, 1)
                                                ]),
                                    ),
                                    child:
                                        textstyle(' منجز', 17.0, Colors.white),
                                  )),
                            ],
                          ),
                        ),
                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        //?----End of first section including the two buttons
                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        //?----------Scound section the to do list
                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        //-----------space------------------
                        SizedBox(
                          height: height * 0.02,
                        ),
                        //-----------End of space------------------
                        Container(
                          //!remove
                          // color: Colors.amberAccent,
                          //!remove
                          height: height,
                          width: width * 0.9,
                          child: Center(
                              child: ListView.builder(
                            itemCount: todoList.length,
                            itemBuilder: (context, index) {
                              final todoItem = todoList[index];
                              if (todoItem.completed == true && done == true) {
                                return Container(
                                  decoration: whiteBoxDecorstion(),
                                  margin: const EdgeInsets.all(8),
                                  child: Row(
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(25),
                                          boxShadow: const [
                                            BoxShadow(
                                              color:
                                                  Color.fromRGBO(0, 0, 0, 0.25),
                                              blurRadius: 4,
                                              spreadRadius: -2,
                                              offset: Offset(0, 1),
                                            ),
                                          ],
                                        ),
                                        child: Image(
                                          image: const AssetImage(
                                            'assets/images/icons8-check 1.png',
                                          ),
                                          width: width * 0.08,
                                        ),
                                      ),
                                      Expanded(
                                        child: ListTile(
                                          title: textstyle(
                                            todoItem.title.toString(),
                                            20.0,
                                            Colors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              } else if (todoItem.completed == false &&
                                  done == false) {
                                return Container(
                                  decoration: whiteBoxDecorstion(),
                                  margin: const EdgeInsets.all(8),
                                  child: Row(
                                    children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(25),
                                          boxShadow: const [
                                            BoxShadow(
                                              color:
                                                  Color.fromRGBO(0, 0, 0, 0.25),
                                              blurRadius: 4,
                                              spreadRadius: -2,
                                              offset: Offset(0, 1),
                                            ),
                                          ],
                                        ),
                                        child: Image(
                                          image: const AssetImage(
                                            'assets/images/Vector.png',
                                          ),
                                          width: width * 0.08,
                                        ),
                                      ),
                                      Expanded(
                                        child: ListTile(
                                          title: textstyle(
                                            todoItem.title.toString(),
                                            20.0,
                                            Colors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ); // Return an empty container for incomplete items
                              } else {
                                return Container();
                              }
                            },
                          )),
                        ),

                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        //?------End Scound section including the two buttons
                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        //-----------space------------------
                        SizedBox(
                          height: height * 0.001,
                        ),
                        //-----------End of space------------------
                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                        //?----------Third section including the two buttons
                        //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                      ],
                    ),
                  ),
                  Center(
                    child: Container(
                      margin: EdgeInsets.only(top: height * 0.7),
                      height: height * 0.1,
                      width: width * 0.22,
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.black.withOpacity(0.06), width: 7),
                          gradient: const LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Color.fromARGB(255, 108, 180, 209),
                                Color.fromRGBO(64, 226, 190, 1)
                              ]),
                          boxShadow: const [
                            BoxShadow(
                                color: Color.fromRGBO(187, 241, 234, 1),
                                spreadRadius: -2,
                                offset: Offset(0, 0),
                                blurRadius: 54)
                          ],
                          borderRadius: BorderRadius.circular(1000)),
                      child: const Icon(
                        Icons.add_rounded,
                        size: 60,
                        color: Colors.white,
                        weight: 4,
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ));
  }

  BoxDecoration whiteBoxDecorstion() {
    return BoxDecoration(
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                        color: Colorss.gray.withOpacity(0.3),
                                        offset: Offset(0, 0),
                                        spreadRadius: -2,
                                        blurRadius: 10),
                                  ],
                                  border: Border.all(
                                      color: Colors.black.withOpacity(0.10),
                                      width: 3),
                                );
  }

  Text textstyle(todoItem, fontsize, color) {
    return Text(todoItem,
        style: GoogleFonts.elMessiri(
          textStyle: TextStyle(
              fontSize: fontsize, color: color, fontWeight: FontWeight.bold),
        ));
  }
}
